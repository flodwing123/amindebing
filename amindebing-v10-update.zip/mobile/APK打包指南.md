# 📱 啊敏的兵 · 手机 App（APK）打包指南

> 本目录是「啊敏的兵」的 **APK 打包工程**。网页源码在上级目录 `teacher-workbench/`，
> 打包时自动复用同一份代码，**不会有两份代码不一致的问题**。

---

## 三种方案，按需选择

| 方案 | 需要什么 | 效果 |
|------|---------|------|
| **方案一（推荐）** Capacitor + Android Studio | 一台电脑 + Node.js + Android Studio | 生成真正的 `.apk` 安装包，可装安卓手机 |
| **方案二** DCloud HBuilderX 云打包 | 一台电脑 + HBuilderX | 免装 Android Studio，云端免费打 APK |
| **方案三（最快）** PWA 添加到主屏幕 | 手机浏览器即可 | 不用打 APK，手机桌面生成 App 图标，离线可用 |

---

## 方案一：Capacitor + Android Studio 打 APK（推荐）

### 1. 准备环境
- 安装 **Node.js**（≥ 18）：https://nodejs.org
- 安装 **Android Studio**（含 Android SDK）：https://developer.android.com/studio
  - 首次启动后按向导安装 SDK Platform 34 + Build Tools

### 2. 打包（在本 `mobile/` 目录操作）
```bash
# ① 安装依赖（第一次即可）
npm install

# ② 生成 Android 工程
npx cap add android

# ③ 把网页代码同步进 Android 工程（改完网页后要重新执行）
npx cap sync

# ④ 用 Android Studio 打开
npx cap open android
```
在 Android Studio 中：
- 菜单 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
- 等待构建完成，弹窗点 **locate** 查看 APK

### 3. APK 在哪里
```
mobile/android/app/build/outputs/apk/debug/app-debug.apk
```
把这个文件传到手机（微信/QQ/数据线），点击安装即可。
> 手机安装第三方 APK 需在「设置-安全」里允许未知来源。

### 4. 以后更新网页后怎么重打包
```bash
npx cap sync && npx cap open android   # 再点一次 Build APK 即可
```

---

## 方案二：HBuilderX 云打包（免装 Android Studio）

1. 下载 HBuilderX：https://www.dcloud.io/hbuilderx.html
2. 新建项目 → 选择「5+ App」模板（或 uni-app 空模板）
3. 把 `teacher-workbench/` 下的文件（index.html、css、js、manifest.json、icons）全部复制进项目根目录
4. 双击 `manifest.json` → 「App 图标配置」「App 模块配置」按需填写
5. 菜单 **发行 → 原生App-云打包** → 选 Android → 使用公共测试证书 → 打包
6. 打包完成后下载 `.apk` 安装到手机

---

## 方案三：PWA 添加到主屏幕（最快，无需打 APK）

手机浏览器打开云端链接：
**https://45c5f8674f4e49359ea4a8c75b0f51f6.app.workbuddy.link**

- **安卓 Chrome / 华为浏览器**：右上角菜单 →「添加到主屏幕」→ 桌面出现「啊敏的兵」图标，像 App 一样全屏运行
- **苹果 Safari**：分享 →「添加到主屏幕」
- 已开启离线缓存：首次打开后，**没网也能用**

---

## 🔄 手机端与电脑端数据同步

工作台数据保存在**各设备的浏览器本地**（localStorage），互不自动同步。同步方法：

1. **备份**：任一端点左侧「💾 备份」→ 下载 `啊敏的兵备份_日期.json`
2. **互传**：把 json 文件通过微信/QQ/网盘发到另一端
3. **恢复**：另一端点左侧「📥 恢复」→ 选择该 json → 自动刷新即完成同步

> 💡 建议：每天下班前备份一次，每周在手机/电脑之间同步一次，双端数据一致。

---

## 常见问题

- **安装提示「应用未安装」**：多为签名问题，用方案一自己打包（debug 签名）即可，或改用方案三 PWA。
- **APK 里数据会丢吗**：不会。数据存手机本地的 WebView 存储中，正常使用与网页版体验一致；卸载 App 会清空，请定期备份。
- **想改 App 图标**：替换 `icons/icon-192.png` 与 `icons/icon-512.png` 后重新打包。
