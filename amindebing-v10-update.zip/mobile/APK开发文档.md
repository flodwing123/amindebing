# 📱 啊敏的兵 · APK 开发技术文档

> **版本**：V8  
> **项目**：班主任工作台（啊敏的兵）  
> **技术栈**：纯 HTML + CSS + 原生 JavaScript（无框架依赖）  
> **打包目标**：Android APK 安装包  
> **项目根目录**：`teacher-workbench/`

---

## 一、项目架构概述

### 1.1 技术选型

| 层面 | 技术 | 说明 |
|------|------|------|
| 前端 | HTML5 + CSS3 + 原生 JS | 无 React/Vue 等框架，零编译零依赖 |
| 存储 | localStorage | 数据保存在浏览器本地，`teacher_workbench_` 前缀 |
| 离线 | Service Worker (PWA) | `sw.js` 网络优先策略，离线回退缓存 |
| 云同步 | jsonbin.io (可选) | 免费 JSON 云存储，手机电脑数据自动同步 |
| 打包 | Capacitor 6.x | 将 Web 应用包装为原生 Android 应用 |

### 1.2 文件结构

```
teacher-workbench/
├── index.html          # 主页面（引入所有 JS/CSS）
├── manifest.json       # PWA 清单（App 名称、图标、主题色）
├── sw.js               # Service Worker（缓存版本 amindebing-v8）
├── css/
│   └── style.css       # 全部样式（~1100 行）
├── js/
│   ├── quotes.js       # 每日金句数据
│   ├── data.js         # 数据层（Store 封装、默认数据、Today 工具）
│   ├── modules.js      # 班级管理模块（座次表、考勤、值日等）
│   ├── modules2.js     # 学生信息/作业/事件绑定/座次表AI
│   ├── grade-analysis.js  # 成绩分析模块（V8 新增）
│   ├── discipline.js   # 违纪统计模块（V8 新增）
│   ├── leave.js        # 请假管理模块（V8 新增）
│   ├── cloud-sync.js   # 云端同步模块（V8 新增）
│   ├── meeting.js      # 每周班会模块
│   ├── parentmeet.js   # 家长会模块
│   ├── vault.js        # 数据保险库模块
│   ├── ideas.js        # 奇思妙想模块
│   ├── study.js        # 我爱学习模块
│   ├── monthly.js      # 每月小结模块
│   └── app.js          # 主应用（侧边栏路由、首页看板、模块注册）
├── icons/
│   ├── icon-192.png    # PWA 图标 192x192
│   └── icon-512.png    # PWA 图标 512x512
├── mobile/             # APK 打包工程
│   ├── package.json    # Capacitor 依赖
│   ├── capacitor.config.json  # Capacitor 配置
│   └── APK开发文档.md  # 本文档
└── README.md           # 使用说明书
```

### 1.3 模块清单（16 大模块）

| # | 模块名 | 类型标识 | JS 文件 |
|---|--------|---------|--------|
| 1 | 今日待办 | dashboard | app.js |
| 2 | 学生信息 | student | modules2.js |
| 3 | 成绩分析 | grade | grade-analysis.js |
| 4 | 违纪统计 | discipline | discipline.js |
| 5 | 作业提效 | homework | modules2.js |
| 6 | 请假管理 | leave | leave.js |
| 7 | 班级管理 | class | modules.js + modules2.js |
| 8 | 早日退休 | retirement | modules.js |
| 9 | 课程表 | timetable | modules.js |
| 10 | 备课助手 | lesson | modules.js |
| 11 | 家校沟通 | comm | modules.js |
| 12 | 荣誉登记 | honor | modules.js |
| 13 | 奇思妙想 | ideas | ideas.js |
| 14 | 我爱学习 | study | study.js |
| 15 | 数据保险库 | vault | vault.js |
| 16 | 每月小结 | monthly | monthly.js |

---

## 二、方案一：Capacitor + Android Studio 打 APK（推荐）

### 2.1 环境准备

#### 必装软件

| 软件 | 版本要求 | 下载地址 |
|------|---------|---------|
| Node.js | ≥ 18 LTS | https://nodejs.org |
| Android Studio | ≥ Hedgehog (2023.1) | https://developer.android.com/studio |
| JDK | 17（Android Studio 自带） | 随 Android Studio 安装 |

#### Android SDK 配置

首次启动 Android Studio 后：
1. 菜单 **Tools → SDK Manager**
2. 勾选 **Android API 34 (Android 14)** 或 **API 33**
3. 切到 **SDK Tools** 标签，确保以下已勾选：
   - Android SDK Build-Tools 34
   - Android SDK Platform-Tools
   - Android Emulator（可选，用于模拟器测试）

#### 环境变量（Windows）

```
ANDROID_HOME = C:\Users\你的用户名\AppData\Local\Android\Sdk
PATH 追加：%ANDROID_HOME%\platform-tools
```

验证：`adb version` 能输出版本号即可。

### 2.2 Capacitor 配置

#### 2.2.1 capacitor.config.json 说明

```json
{
  "appId": "com.amindebing.workbench",
  "appName": "啊敏的兵",
  "webDir": "..",
  "server": {
    "androidScheme": "https"
  }
}
```

| 字段 | 说明 |
|------|------|
| `appId` | Android 应用包名，唯一标识 |
| `appName` | 手机桌面显示的名称 |
| `webDir` | 网页源码目录（`..` 指向 `teacher-workbench/` 根目录） |
| `androidScheme` | 使用 HTTPS 协议加载本地页面（避免混合内容警告） |

#### 2.2.2 package.json 说明

```json
{
  "name": "amindebing-mobile",
  "version": "8.0.0",
  "private": true,
  "dependencies": {
    "@capacitor/android": "^6.0.0",
    "@capacitor/core": "^6.0.0"
  }
}
```

### 2.3 打包步骤

#### 步骤 1：安装依赖

```bash
cd mobile
npm install
```

#### 步骤 2：初始化 Android 工程

```bash
npx cap add android
```

> 此命令在 `mobile/android/` 下生成完整的 Android Studio 工程。**首次执行即可，后续不需要重复。**

#### 步骤 3：同步网页代码到 Android 工程

```bash
npx cap sync android
```

> **每次修改网页代码后都需要重新执行此命令**，将最新的 HTML/CSS/JS 复制到 Android 工程的 `assets/` 目录中。

#### 步骤 4：在 Android Studio 中打开

```bash
npx cap open android
```

#### 步骤 5：构建 APK

在 Android Studio 中：
1. 菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. 等待 Gradle 构建完成（首次约 3-5 分钟）
3. 弹出通知 **"APK(s) generated successfully"** → 点击 **locate**
4. 或手动找到 APK 文件：

```
mobile/android/app/build/outputs/apk/debug/app-debug.apk
```

#### 步骤 6：安装到手机

- 通过微信/QQ/数据线将 APK 传到手机
- 手机点击安装（需在「设置 → 安全」中允许「未知来源安装」）

### 2.4 以后更新网页后重新打包

```bash
# 在 mobile/ 目录执行
npx cap sync android
npx cap open android
# Android Studio 中 Build → Build APK(s) 即可
```

### 2.5 生成 Release 签名 APK（用于发布）

#### 创建签名密钥

```bash
keytool -genkey -v -keystore amindebing.keystore -alias amindebing -keyalg RSA -keysize 2048 -validity 10000
```

按提示输入密码和身份信息。**请妥善保管 keystore 文件，丢失后无法更新应用。**

#### 配置 Gradle 签名

在 `mobile/android/app/build.gradle` 的 `android { }` 块中添加：

```gradle
signingConfigs {
  release {
    storeFile file('../../amindebing.keystore')
    storePassword '你的密码'
    keyAlias 'amindebing'
    keyPassword '你的密码'
  }
}
buildTypes {
  release {
    signingConfig signingConfigs.release
    minifyEnabled false
    proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
  }
}
```

#### 构建 Release APK

菜单 **Build → Generate Signed Bundle / APK → APK → 选择 release** → Build

APK 路径：
```
mobile/android/app/build/outputs/apk/release/app-release.apk
```

---

## 三、方案二：HBuilderX 云打包（免装 Android Studio）

### 3.1 适用场景

- 没有安装 Android Studio 的条件
- 需要快速生成 APK 进行测试
- 不需要自定义原生功能

### 3.2 步骤

1. 下载安装 **HBuilderX**：https://www.dcloud.io/hbuilderx.html
2. 新建项目 → 选择 **「5+ App」** 模板
3. 把 `teacher-workbench/` 下的全部文件复制进项目根目录：
   - `index.html`
   - `css/` 目录
   - `js/` 目录
   - `manifest.json`
   - `icons/` 目录
4. 编辑 `manifest.json`：
   - **App 图标配置**：上传 `icons/icon-192.png`
   - **App 模块配置**：保持默认即可（不需要额外模块）
   - **App 基本信息配置**：应用名称填「啊敏的兵」，包名 `com.amindebing.workbench`
5. 菜单 **发行 → 原生App-云打包**
6. 选择 **Android** → 勾选 **使用公共测试证书** → 点击打包
7. 等待云端打包完成（约 2-5 分钟），下载 `.apk` 安装到手机

### 3.3 更新网页后重新打包

重新复制最新网页文件到 HBuilderX 项目 → 再次 **云打包** 即可。

---

## 四、方案三：PWA 添加到主屏幕（最快，无需打 APK）

### 4.1 适用场景

- 不需要安装包文件
- 手机已能访问云端链接
- 想要 App 图标在桌面、全屏运行、离线可用

### 4.2 操作

手机浏览器打开云端链接：
```
https://45c5f8674f4e49359ea4a8c75b0f51f6.app.workbuddy.link
```

| 手机系统 | 操作 |
|---------|------|
| Android Chrome | 右上角菜单 →「添加到主屏幕」 |
| Android 华为浏览器 | 右下角菜单 →「添加到」→「主屏幕」 |
| iOS Safari | 底部分享按钮 →「添加到主屏幕」 |

添加后桌面出现「啊敏的兵」图标，点击即可全屏运行。首次打开后资源全部缓存，**没网也能用**。

### 4.3 PWA 技术细节

- **manifest.json**：定义 App 名称、图标、启动方式、主题色
- **sw.js**：Service Worker，缓存策略为「网络优先，失败回退缓存」
- **缓存版本**：`amindebing-v8`（每次更新网页需递增版本号，强制刷新缓存）
- **预缓存列表**：包含全部 15 个 JS 文件 + CSS + HTML + 图标

---

## 五、云端数据同步配置

### 5.1 原理

工作台数据保存在各设备的浏览器本地（localStorage），默认不互通。通过配置免费云端 JSON 存储（推荐 jsonbin.io），可实现：

- 数据变更后自动推送（3 秒防抖）
- 打开应用时自动拉取
- 时间戳判断新旧，自动覆盖旧数据

### 5.2 配置步骤

1. 注册 **jsonbin.io**（免费 10MB 足够）
2. 创建一个新 Bin（内容随意，如 `{}`)
3. 获取 **Bin ID** 和 **Master Key**
4. 打开工作台 → 「数据保险库」→ 底部「☁️ 云端同步设置」
5. 填入：
   - API 地址：`https://api.jsonbin.io/v3/b`
   - API Key：你的 Master Key
   - Bin ID：你的 Bin ID
   - 勾选「开启自动同步」
6. 点击「💾 保存配置」→ 「⬆️ 立即推送」首次上传

### 5.3 技术实现

| 组件 | 说明 |
|------|------|
| `cloud-sync.js` | 同步核心模块 |
| 数据收集 | `syncCollectData()` 遍历所有 `teacher_workbench_*` 键 |
| 推送 | `syncPush()` PUT 请求到 jsonbin.io |
| 拉取 | `syncPull()` GET 请求 + 时间戳比较 |
| 自动推送 | 包装 `Store.set`，每次数据写入触发 3 秒防抖推送 |
| 自动拉取 | 应用启动时调用 `syncAutoPull()` |

---

## 六、构建配置详解

### 6.1 Service Worker 缓存策略

```javascript
// sw.js 核心策略
const CACHE = "amindebing-v8";  // 每次更新递增
const STATIC = [/* 预缓存文件列表 */];

// 策略：网络优先 → 失败回退缓存 → 最终回退 index.html
fetch(req).then(res => {
  caches.open(CACHE).then(c => c.put(req, res.clone()));  // 更新缓存
  return res;
}).catch(() => caches.match(req));
```

**更新缓存版本的时机**：
- 新增 JS 文件时
- 修改了 JS 文件内容时
- 修改了 CSS 内容时
- 修改了 manifest.json 时

### 6.2 Capacitor WebView 配置

Capacitor 默认使用 Android System WebView 加载网页。应用内行为与浏览器一致：
- localStorage 可正常使用
- Service Worker 在 WebView 中**不生效**（Capacitor 限制）
- 离线缓存由 Capacitor 本地资源替代（所有文件已打包进 APK）

### 6.3 应用图标

| 用途 | 文件 | 尺寸 |
|------|------|------|
| PWA | `icons/icon-192.png` | 192x192 |
| PWA | `icons/icon-512.png` | 512x512 |
| Android | Capacitor 自动从 PWA 图标生成 | 自动适配 |

更换图标后：替换 `icons/` 下的文件 → 重新 `npx cap sync` → 重新打包 APK。

---

## 七、更新与发布流程

### 7.1 修改网页代码后的更新流程

```
修改 JS/CSS/HTML
    ↓
node --check 全部 JS 语法检查
    ↓
更新 sw.js 缓存版本号（如 v8 → v9）
    ↓
如有新增 JS 文件：更新 sw.js 预缓存列表 + index.html <script> 标签
    ↓
npx cap sync android  （同步到 Android 工程）
    ↓
Android Studio: Build → Build APK
    ↓
将新 APK 传到手机安装
    ↓
云端重新部署（cloudstudio-deploy 或类似工具）
```

### 7.2 版本管理建议

- `sw.js` 中的 `CACHE` 版本号与 `package.json` 的 `version` 保持一致
- 每次大版本升级递增主版本号（V7 → V8 → V9）
- 保留历史 APK 文件备份

---

## 八、常见问题

| 问题 | 解决方案 |
|------|---------|
| APK 安装提示「应用未安装」 | 多为签名问题，使用方案一 debug 签名打包，或改用方案三 PWA |
| APK 中数据丢失 | 数据存在 WebView 的 localStorage 中，正常使用不会丢；卸载 App 会清空，请定期备份 |
| APK 启动白屏 | 检查 `webDir` 路径是否正确指向 `..`（teacher-workbench 根目录） |
| APK 中无法访问外链 | Capacitor WebView 默认拦截外部导航，在 `capacitor.config.json` 中配置 `server.allowNavigation` |
| 云端同步不生效 | 检查 jsonbin.io 配置是否正确，API Key 和 Bin ID 是否有效 |
| Service Worker 不更新 | 递增 `sw.js` 中的 `CACHE` 版本号，旧缓存会自动清除 |
| 图标不显示 | 确保 `icons/` 目录下有 `icon-192.png` 和 `icon-512.png`，重新 `npx cap sync` |
| 构建速度慢 | Android Studio 首次 Gradle 构建需下载依赖，约 5-10 分钟，后续构建会快很多 |

---

## 九、调试技巧

### 9.1 Android WebView 远程调试

1. 手机开启 **开发者选项 → USB 调试**
2. USB 连接电脑
3. 电脑 Chrome 浏览器地址栏输入 `chrome://inspect`
4. 在设备列表中找到「啊敏的兵」→ 点击 **inspect**
5. 可查看 Console、Network、LocalStorage 等

### 9.2 模拟器测试

Android Studio → **Tools → Device Manager → Create Virtual Device** → 选择手机型号 → 下载系统镜像 → 启动模拟器 → 运行 App

---

## 十、附录

### 10.1 Capacitor 常用命令

| 命令 | 说明 |
|------|------|
| `npx cap add android` | 初始化 Android 工程（仅首次） |
| `npx cap sync android` | 同步网页代码到 Android 工程 |
| `npx cap open android` | 用 Android Studio 打开 Android 工程 |
| `npx cap copy android` | 仅复制网页文件（不执行 Gradle 同步） |
| `npx cap update android` | 更新 Android 依赖 |

### 10.2 关键文件索引

| 文件 | 路径 | 说明 |
|------|------|------|
| 主页面 | `index.html` | 引入所有 JS/CSS |
| 数据层 | `js/data.js` | Store 封装、默认数据 |
| 主应用 | `js/app.js` | 侧边栏路由、首页看板 |
| Service Worker | `sw.js` | 离线缓存策略 |
| PWA 清单 | `manifest.json` | App 名称、图标、主题 |
| Capacitor 配置 | `mobile/capacitor.config.json` | 包名、Web 目录 |
| 依赖清单 | `mobile/package.json` | Capacitor 版本 |
