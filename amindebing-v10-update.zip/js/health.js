/* =========================================================
   🏥 特异体质登记 · 学生健康特殊关注名单
   登记特异体质学生信息：姓名、病史、用药、注意事项、家长知情书
   首页 dashboard 显示提醒卡片
   数据 key: healthRecords = [{id, name, cls, diseaseType, medication, notes, consentSigned, createdAt}]
   ========================================================= */

registerModule("health", {
  title: "🏥 特异体质登记",
  sub: "特异体质学生 · 病史 · 用药 · 注意事项 · 家长知情书",
  render() {
    return `
    <div class="mv-header"><h2 class="mv-title">🏥 特异体质登记 <span style="font-size:13px;color:var(--ink-light);font-weight:400">特殊健康关注名单</span></h2>
      <p class="mv-sub">登记特异体质学生 · 用药情况 · 注意事项 · 家长知情书签署</p></div>
    ${modToolbar("特异体质登记")}
    <div id="healthBody">${renderHealth()}</div>`;
  },
  after() {
    bindHealthEvents();
  }
});

/* 颜色映射：病史类型 */
const HEALTH_DISEASE_COLORS = {
  "哮喘": "#E8835A",
  "心脏病": "#C0564D",
  "癫痫": "#8B5CF6",
  "糖尿病": "#3A6B9B",
  "过敏体质": "#F6A623",
  "视力障碍": "#3B82F6",
  "听力障碍": "#10B981",
  "肢体残疾": "#6B7280",
  "心理疾病": "#EC4899",
  "其他": "#6B7280"
};

const HEALTH_DISEASE_TYPES = Object.keys(HEALTH_DISEASE_COLORS);

function getHealthRecords() {
  return Store.get("healthRecords", []);
}
function saveHealthRecords(list) {
  Store.set("healthRecords", list);
}

function healthDiseaseBadge(type) {
  const color = HEALTH_DISEASE_COLORS[type] || HEALTH_DISEASE_COLORS["其他"];
  return `<span style="display:inline-block;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:700;color:#fff;background:${color}">${esc(type || "其他")}</span>`;
}

function renderHealth() {
  const records = getHealthRecords();
  const classes = Store.get("classes", defaultClasses());

  /* 统计区 */
  const byType = {};
  records.forEach(r => {
    const t = r.diseaseType || "其他";
    byType[t] = (byType[t] || 0) + 1;
  });
  const consentSigned = records.filter(r => r.consentSigned === "已签").length;
  const consentUnsigned = records.length - consentSigned;

  let statsHtml = `<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px">
    <span class="stat-chip">🏥 共 ${records.length} 名特异体质学生</span>
    <span class="stat-chip" style="color:#27ae60">✅ 知情书已签 ${consentSigned}</span>
    ${consentUnsigned > 0 ? `<span class="stat-chip" style="color:#e74c3c">⚠️ 知情书未签 ${consentUnsigned}</span>` : ""}
  </div>`;

  /* 病史类型分布 */
  if (records.length > 0) {
    statsHtml += `<div style="font-size:13px;font-weight:600;margin:4px 0 8px;color:var(--ink-soft)">📋 病史类型分布</div>
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px">
      ${Object.keys(byType).map(t => `<span style="display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:8px;background:var(--green-50);font-size:12px">
        ${healthDiseaseBadge(t)} <b style="color:var(--ink-soft)">${byType[t]} 人</b>
      </span>`).join("")}
    </div>`;
  }

  /* 记录列表 */
  let listHtml = "";
  if (records.length === 0) {
    listHtml = `<div class="empty"><span class="e-ico">🏥</span>
      暂无特异体质登记记录。点击「＋ 登记学生」添加需要特别关注的特异体质学生。<br>
      <span style="font-size:12px;color:var(--ink-light)">登记后将在首页显示提醒卡片，方便班主任日常关注。</span>
    </div>`;
  } else {
    listHtml = `<div class="tbl-wrap"><table class="tbl">
      <thead><tr>
        <th style="width:60px">#</th>
        <th style="width:80px">姓名</th>
        <th style="width:80px">班级</th>
        <th style="width:100px">病史类型</th>
        <th>用药情况</th>
        <th>注意事项</th>
        <th style="width:80px">知情书</th>
        <th style="width:70px">操作</th>
      </tr></thead>
      <tbody>
        ${records.map((r, i) => `<tr>
          <td class="num">${i + 1}</td>
          <td style="font-weight:600;color:var(--green-800)">${esc(r.name || "")}</td>
          <td>${esc(r.cls || "")}</td>
          <td style="white-space:nowrap">${healthDiseaseBadge(r.diseaseType)}</td>
          <td style="max-width:200px;white-space:pre-wrap;word-break:break-all">${esc(r.medication || "—")}</td>
          <td style="max-width:240px;white-space:pre-wrap;word-break:break-all">${esc(r.notes || "—")}</td>
          <td style="white-space:nowrap">${r.consentSigned === "已签"
            ? `<span style="color:#27ae60;font-weight:700">✅ 已签</span>`
            : `<span style="color:#e74c3c;font-weight:700">⚠️ 未签</span>`}</td>
          <td class="num">
            <button class="btn btn-ghost btn-sm" data-act="health-edit" data-id="${esc(r.id)}" style="margin-bottom:4px">编辑</button>
            <button class="btn btn-danger btn-sm" data-act="health-del" data-id="${esc(r.id)}">删除</button>
          </td>
        </tr>`).join("")}
      </tbody>
    </table></div>`;
  }

  return `<div class="card">
    <div class="card-title">🏥 特异体质登记 <span class="sub">特殊健康关注名单 · 首页自动提醒</span>
      <button class="btn btn-primary btn-sm" data-act="health-add">＋ 登记学生</button>
      <button class="btn btn-ghost btn-sm" data-act="health-export">⬇️ 导出</button>
    </div>
    ${statsHtml}
    ${listHtml}
    <div style="margin-top:12px;font-size:12px;color:var(--ink-light);line-height:1.8">
      💡 登记后首页将显示特异体质提醒卡片。建议开学初完成排查登记，并确保家长知情书全部签署。
    </div>
  </div>`;
}

function healthOpenAdd(editId) {
  const records = getHealthRecords();
  const editing = editId ? records.find(r => r.id === editId) : null;
  const classes = Store.get("classes", defaultClasses());
  const students = Store.get("students", {});
  const allStuNames = [];
  Object.keys(students).forEach(cls => {
    (students[cls] || []).forEach(s => allStuNames.push({ name: s.name, cls: cls }));
  });

  const e = editing || {};
  const today = Today.now();

  openModal(`
    <div style="display:grid;gap:12px">
      <div>
        <label class="lbl" style="display:block;font-size:12px;margin-bottom:4px;color:var(--ink-soft)">学生姓名</label>
        <input class="inp" id="hlthName" value="${esc(e.name || "")}" placeholder="输入或选择学生姓名" list="hlthNameList" style="width:100%">
        <datalist id="hlthNameList">${allStuNames.map(s => `<option value="${esc(s.name)}">${esc(s.cls)}</option>`).join("")}</datalist>
      </div>
      <div>
        <label class="lbl" style="display:block;font-size:12px;margin-bottom:4px;color:var(--ink-soft)">班级</label>
        <select class="inp" id="hlthCls" style="width:100%">
          <option value="">选择班级</option>
          ${classes.map(c => `<option value="${esc(c.name)}" ${e.cls === c.name ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
        </select>
      </div>
      <div>
        <label class="lbl" style="display:block;font-size:12px;margin-bottom:4px;color:var(--ink-soft)">病史类型 <span style="color:var(--ink-light)">（颜色区分）</span></label>
        <select class="inp" id="hlthDisease" style="width:100%">
          ${HEALTH_DISEASE_TYPES.map(t => `<option value="${t}" ${e.diseaseType === t ? "selected" : ""} style="color:${HEALTH_DISEASE_COLORS[t]};font-weight:700">${t}</option>`).join("")}
        </select>
      </div>
      <div>
        <label class="lbl" style="display:block;font-size:12px;margin-bottom:4px;color:var(--ink-soft)">用药情况</label>
        <textarea class="inp" id="hlthMedication" rows="2" placeholder="如：随身携带沙丁胺醇气雾剂，发作时按压2喷" style="width:100%;resize:vertical">${esc(e.medication || "")}</textarea>
      </div>
      <div>
        <label class="lbl" style="display:block;font-size:12px;margin-bottom:4px;color:var(--ink-soft)">注意事项</label>
        <textarea class="inp" id="hlthNotes" rows="3" placeholder="如：避免剧烈运动，体育课需旁站观察；发作时立即通知家长" style="width:100%;resize:vertical">${esc(e.notes || "")}</textarea>
      </div>
      <div>
        <label class="lbl" style="display:block;font-size:12px;margin-bottom:4px;color:var(--ink-soft)">家长知情书签署</label>
        <select class="inp" id="hlthConsent" style="width:100%">
          <option value="已签" ${e.consentSigned === "已签" ? "selected" : ""} style="color:#27ae60;font-weight:700">✅ 已签</option>
          <option value="未签" ${(e.consentSigned || "未签") === "未签" ? "selected" : ""} style="color:#e74c3c;font-weight:700">⚠️ 未签</option>
        </select>
      </div>
    </div>
  `, editing ? "编辑特异体质登记" : "登记特异体质学生");

  const ok = document.querySelector("[data-act=modal-ok]");
  if (ok) ok.onclick = healthSaveRecord;
}

function healthSaveRecord() {
  const name = (document.getElementById("hlthName") || {}).value.trim();
  const cls = (document.getElementById("hlthCls") || {}).value;
  const diseaseType = (document.getElementById("hlthDisease") || {}).value;
  const medication = (document.getElementById("hlthMedication") || {}).value.trim();
  const notes = (document.getElementById("hlthNotes") || {}).value.trim();
  const consentSigned = (document.getElementById("hlthConsent") || {}).value || "未签";

  if (!name) return toast("请填写学生姓名");
  if (!diseaseType) return toast("请选择病史类型");

  const list = getHealthRecords();

  /* 检查是否编辑已有记录 */
  const editId = document.querySelector("[data-act=modal-ok]").dataset.editId;
  if (editId) {
    const idx = list.findIndex(r => r.id === editId);
    if (idx >= 0) {
      list[idx] = { ...list[idx], name, cls, diseaseType, medication, notes, consentSigned, updatedAt: new Date().toISOString() };
      saveHealthRecords(list);
      closeModal();
      refreshHealthView();
      toast("✅ 已更新特异体质登记");
      return;
    }
  }

  /* 新增：查重（同一学生不重复登记） */
  if (list.some(r => r.name === name && r.cls === cls)) {
    return toast("该学生已登记，请勿重复添加");
  }

  list.push({
    id: uid(), name, cls, diseaseType,
    medication: medication || "—",
    notes: notes || "—",
    consentSigned,
    createdAt: new Date().toISOString()
  });
  saveHealthRecords(list);
  closeModal();
  refreshHealthView();
  toast("✅ 特异体质登记成功，首页将显示提醒");
}

function refreshHealthView() {
  const body = document.getElementById("healthBody");
  if (body) {
    body.innerHTML = renderHealth();
    bindHealthEvents();
  }
}

function bindHealthEvents() {
  document.querySelector("[data-act=health-add]")?.addEventListener("click", () => healthOpenAdd(null));

  document.querySelectorAll("[data-act=health-edit]").forEach(btn => {
    btn.onclick = () => {
      const id = btn.dataset.id;
      const ok = document.querySelector("[data-act=modal-ok]");
      if (ok) ok.dataset.editId = id;
      healthOpenAdd(id);
      /* 修复：openModal 会重新创建 ok 按钮，需要再次设置 */
      setTimeout(() => {
        const okBtn = document.querySelector("[data-act=modal-ok]");
        if (okBtn) {
          okBtn.dataset.editId = id;
          okBtn.onclick = healthSaveRecord;
        }
      }, 50);
    };
  });

  document.querySelectorAll("[data-act=health-del]").forEach(btn => {
    btn.onclick = () => {
      if (!confirm("确定删除这条特异体质登记吗？")) return;
      const id = btn.dataset.id;
      const list = getHealthRecords().filter(r => r.id !== id);
      saveHealthRecords(list);
      refreshHealthView();
      toast("已删除");
    };
  });

  document.querySelector("[data-act=health-export]")?.addEventListener("click", () => {
    const list = getHealthRecords();
    if (!list.length) { toast("暂无记录可导出"); return; }
    const rows = [["姓名", "班级", "病史类型", "用药情况", "注意事项", "知情书", "登记时间"]];
    list.forEach(r => rows.push([
      r.name || "", r.cls || "", r.diseaseType || "",
      r.medication || "", r.notes || "", r.consentSigned || "",
      (r.createdAt || "").replace("T", " ").slice(0, 19)
    ]));
    const csv = "\uFEFF" + rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(",")).join("\n");
    downloadFile("特异体质登记_" + Today.now() + ".csv", csv, "text/csv;charset=utf-8");
    toast("已导出 CSV");
  });
}
