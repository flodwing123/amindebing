/* =========================================================
   实测：Supabase user_sync 单条数据写入大小上限
   用法：node e2e-size.cjs
   原理：逐级增大 data 字段（模拟 base64 图片），找到第一个失败的档位
   ========================================================= */
const fs = require('fs');
const path = require('path');

global.localStorage = (() => {
  const m = new Map();
  return {
    getItem: k => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, String(v)),
    removeItem: k => { m.delete(k); },
    clear: () => m.clear()
  };
})();

const base = __dirname;
const cfgSrc = fs.readFileSync(path.join(base, '..', 'js', 'sb-config.js'), 'utf8');
const clientSrc = fs.readFileSync(path.join(base, '..', 'js', 'supabase.js'), 'utf8');
const SB = new Function(cfgSrc + '\n' + clientSrc + '\nreturn SB;')();

const EMAIL = 'amindebing.verify.size@gmail.com';
const PASSWORD = 'Amindebing#2026Size';

async function main() {
  let user = null;
  try { user = await SB.signIn(EMAIL, PASSWORD); console.log('[INFO] 登录已有账号'); }
  catch (e) {
    console.log('[INFO] 登录失败，注册新账号');
    user = await SB.signUp(EMAIL, PASSWORD);
  }
  const uid = user.id;
  console.log('[INFO] user_id = ' + uid);

  // 各档位：以 base64 字符串字符数计（对应压缩后照片 base64 的大小）
  const sizes = [100, 300, 500, 800, 1000, 1500, 2000, 3000, 4000, 5000]; // KB
  let lastOk = 0, firstFail = null;

  for (const kb of sizes) {
    const chars = kb * 1024;
    const payload = 'A'.repeat(chars);
    const key = 'size_probe';
    try {
      await SB.from('user_sync').upsert([{ user_id: uid, key, data: { t: 'size', blob: payload } }]).exec();
      lastOk = kb;
      console.log(`  [OK]   ${kb} KB (单条请求体约 ${(chars / 1024).toFixed(0)} KB 字符)`);
    } catch (e) {
      firstFail = { kb, status: e.status, msg: String(e.message).slice(0, 160) };
      console.log(`  [FAIL] ${kb} KB -> HTTP ${e.status || '?'} ${String(e.message).slice(0, 160)}`);
      break;
    }
  }

  // 清理探针数据
  try { await SB.from('user_sync').delete().eq('user_id', uid).eq('key', 'size_probe').exec(); console.log('[INFO] 探针数据已清理'); } catch (e) { console.log('[WARN] 清理失败: ' + e.message); }

  console.log('\n========== 结论 ==========');
  console.log(`单条写入上限：至少 ${lastOk} KB 正常；${firstFail ? '在 ' + firstFail.kb + ' KB 处失败(' + (firstFail.status || '无状态码') + ') ' + firstFail.msg : '所有档位全部通过（>=5MB）'}`);
  process.exit(0);
}

main().catch(e => { console.error('[FATAL]', e); process.exit(1); });
