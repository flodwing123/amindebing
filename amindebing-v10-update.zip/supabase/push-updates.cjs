/* =========================================================
   轻量推送脚本：把指定文件推送到 flodwing123/amindebing main 分支
   用法：GH_TOKEN=ghp_xxx node push-updates.cjs "supabase/e2e-verify.cjs" "supabase/部署与验证指南.md"
   说明：token 从环境变量读取，不写入任何文件
   ========================================================= */
const fs = require('fs');
const path = require('path');

const TOKEN = process.env.GH_TOKEN;
if (!TOKEN) { console.error('缺少 GH_TOKEN 环境变量'); process.exit(1); }
const OWNER = 'flodwing123';
const REPO = 'amindebing';
const files = process.argv.slice(2);
if (!files.length) { console.error('请传入要推送的文件路径'); process.exit(1); }

async function putFile(relPath) {
  const abs = path.join(process.cwd(), relPath);
  const content = fs.readFileSync(abs);
  // GitHub API 对路径进行 URL 编码（保留 / 分隔）
  const encPath = relPath.split('/').map(encodeURIComponent).join('/');
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${encPath}`;
  const H = { Authorization: `Bearer ${TOKEN}`, 'User-Agent': 'node', Accept: 'application/vnd.github+json' };

  // 文件已存在则取 sha 用于更新
  let sha = null;
  const get = await fetch(url, { headers: H });
  if (get.ok) { try { sha = (await get.json()).sha; } catch (e) {} }

  const body = { message: `update ${relPath}`, branch: 'main', content: content.toString('base64') };
  if (sha) body.sha = sha;

  const res = await fetch(url, {
    method: 'PUT',
    headers: Object.assign({ 'Content-Type': 'application/json' }, H),
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const txt = await res.text();
    console.error('FAIL ' + relPath + ' (HTTP ' + res.status + ') ' + txt.slice(0, 300));
    process.exitCode = 1;
    return;
  }
  console.log('OK  ' + relPath + (sha ? ' (updated)' : ' (created)'));
}

(async () => {
  for (const f of files) await putFile(f);
  console.log('完成');
})();
